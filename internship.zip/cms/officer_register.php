<?php
include 'config.php';

$message = '';

if(isset($_POST['submit'])){
   // Sanitize and validate input
   $full_name = filter_var($_POST['full_name'], FILTER_SANITIZE_STRING);
   $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
   $phone_number = filter_var($_POST['phone_number'], FILTER_SANITIZE_STRING);
   $username = filter_var($_POST['username'], FILTER_SANITIZE_STRING);
   $password = md5($_POST['password']); // You should use more secure hashing methods like password_hash()

   // Prepare and bind parameters
   $insert = $conn->prepare("INSERT INTO `officer` (full_name, email, phone_number, username, password) VALUES (?, ?, ?, ?, ?)");
   if ($insert === false) {
      die('Database error: ' . $conn->error); // Handle prepare error
   }
   
   $insert->bind_param("sssss", $full_name, $email, $phone_number, $username, $password);

   // Execute statement
   if($insert->execute()){
      $message = 'Registration successful. Please login to continue.';
   }else{
      $message = 'Registration failed. Please try again.';
   }

   $insert->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Counselor Register</title>
   <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;700&display=swap" rel="stylesheet">
   <style>
      body {
         font-family: 'Poppins', sans-serif;
         margin: 0;
         padding: 0;
         background-color: #f0f0f0;
      }

      .form-container {
         max-width: 400px;
         margin: 50px auto;
         padding: 30px;
         background-color: #ffffff; /* Change to a lighter color, e.g., white */
         border-radius: 10px;
         box-shadow: 0 4px 6px rgba(0,0,0,0.1);
         text-align: center;
      }

      h3 {
         color: #4e2f5f;
         margin-bottom: 20px;
      }

      .box {
         padding: 10px;
         margin-bottom: 20px;
         width: 100%;
         border-radius: 5px;
         border: 1px solid #ccc;
         box-sizing: border-box;
      }

      .btn {
         padding: 10px 20px;
         background-color: #4e2f5f;
         color: #fff;
         border: none;
         border-radius: 5px;
         cursor: pointer;
         transition: background-color 0.3s;
      }

      .btn:hover {
         background-color: #693f7b;
      }

      .message {
         background-color: #f8d7da;
         color: #721c24;
         padding: 10px;
         margin-bottom: 20px;
         border-radius: 5px;
         border: 1px solid #f5c6cb;
         text-align: center;
         position: relative;
      }

      .message span {
         display: inline-block;
         vertical-align: middle;
         margin-right: 5px;
      }

      .message i {
         position: absolute;
         top: 50%;
         right: 10px;
         transform: translateY(-50%);
         cursor: pointer;
      }
   </style>
</head>
<body>

<?php if(isset($message)): ?>
   <div class="message">
      <span><?php echo $message; ?></span>
   </div>
<?php endif; ?>

<section class="form-container">

   <form action="" method="post">
      <h3>Officer Register</h3>
      <input type="text" required placeholder="Enter your full name" class="box" name="full_name">
      <input type="email" required placeholder="Enter your email" class="box" name="email">
      <input type="text" required placeholder="Enter your phone number" class="box" name="phone_number">
      <input type="text" required placeholder="Enter your username" class="box" name="username">
      <input type="password" required placeholder="Enter your password" class="box" name="password">
      <p>Already have an account? <a href="officer_login.php">Login Now</a></p>
      <input type="submit" value="Register Now" class="btn" name="submit">
   </form>

</section>

</body>
</html>
