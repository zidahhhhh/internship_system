<?php
// Include database connection file
include_once "config.php";

// SQL query to retrieve data from the student_info table
$sql = "SELECT studentID, studentName, ICNumber, email, parentPhoneNumber, homeAddress, bmGrade, engGrade, muetBand, mentorName FROM students_info";

// Execute the query and get the result
$result = mysqli_query($conn, $sql);

// Check if query executed successfully
if (!$result) {
    die('Error retrieving data: ' . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>i-Training - Student Information</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" integrity="sha512-+4zCK9k+qNFUR5X+cKL9EIR+ZOhtIloNl9GIKS57V1MyNsYpYcUrUeQc9vNfzsWfV28IaLL3i96P9sdNyeRssA==" crossorigin="anonymous" />
    <link rel="stylesheet" href="style.css"> <!-- Adjust the path as per your file structure -->
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;600;700;800;900&family=Quicksand:wght@300;400;500;600;700&display=swap');

        :root{
            --Playfair: 'Playfair Display', serif;
            --Quicksand: 'Quicksand', sans-serif;
            --Roboto: 'Roboto', sans-serif;
            --dark: #3b393d87;
            --exDark: #2b2b2b;
        }
        *{
            padding: 0;
            margin: 0;
            font-family: var(--Quicksand);
        }
        body{
            line-height: 1.4;
            color: var(--dark);
        }
        img{
            width: 100%;
            display: block;
        }
        .container{
            max-width: 1320px;
            margin: 0 auto;
            padding: 0 1.2rem;
        }

        /* header */
        header{
            flex-direction: column;
            justify-content: stretch;
        }
        .navbar{
            background: rgba(0, 0, 0, 0.6);
            padding: 1.2rem;
        }
        .navbar-brand{
            color: #fff;
            font-size: 2rem;
            display: block;
            text-align: center;
            text-decoration: none;
            font-family: var(--Playfair);
            letter-spacing: 1px;
        }
        .navbar-nav{
            padding: 0.8rem 0 0.2rem 0;
            text-align: center;
        }
        .navbar-nav a{
            text-transform: uppercase;
            font-family: var(--Roboto);
            letter-spacing: 1px;
            font-weight: 500;
            color: #fff;
            text-decoration: none;
            display: inline-block;
            padding: 0.4rem 0.1rem;
            letter-spacing: 3px;
            transition: opacity 0.5s ease;
        }
        .navbar-nav a:hover{
            opacity: 0.7;
            color: rgb(221, 102, 102);
        }

        .search-input{
            font-family: var(--Roboto);
            font-size: 1.1rem;
            width: 100%;
            outline: 0;
            padding: 0.6rem 0;
            border: none;
        }
        .search-input::placeholder{
            text-transform: capitalize;
        }
        .search-btn{
            width: 40px;
            font-size: 1.1rem;
            color: var(--dark);
            border: none;
            background: transparent;
            outline: 0;
            cursor: pointer;
        }

        /* design */
        .design{
            padding: 4.5rem 0;
        }
        .title{
            text-align: center;
            padding: 1rem 0;
        }
        .title h2{
            font-family: var(--Playfair);
            font-size: 2.4rem;
            color:indianred;
        }
        .title p{
            text-transform: uppercase;
            padding: 0.6rem 0;
            color:darksalmon;
        }

        .input-box input{
            width: 100%;
            height: 100%;
            background: transparent;
            border: none;
            outline: none;
            border: 2px solid rgba(255, 255, 255, .2);
            border-radius: 40px;
            font-size: 16px;
            color: white;
            padding: 20px 45px 20px 20px;
        }

        .input-box i {
            position: absolute;
            right: 20px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 20px;
        }

        form {
        max-width: 400px;
        background: rgba(0, 0, 0, 0.5);
        color: white;
        border-radius: 10px;
        padding: 30px 40px;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        margin: 0 auto;
        }

        form h1 {
        font-size: 26px;
        text-align: center;
        margin-top: 20px;
        color: lightblue;
        }

        /* Style the input boxes */
        .input-box {
        position: relative;
        width: 75%;
        height: 50px;
        margin: 20px 0;
        }

        .center {
        text-align: center;
        }

        .input-box input {
        width: 100%;
        height: 100%;
        background: transparent;
        border: none;
        outline: none;
        border: 2px solid rgba(255, 255, 255, 0.2);
        border-radius: 40px;
        font-size: 16px;
        color: white;
        padding: 20px 45px 20px 20px;
        }

        .input-box i {
        position: absolute;
        right: 20px;
        top: 50%;
        transform: translateY(-50%);
        font-size: 20px;
        }

        /* Style the "Login" button */
        button {
        width: 100%;
        padding: 10px;
        background-color: #333;
        color: #fff;
        text-decoration: none;
        border: none;
        cursor: pointer;
        border-radius: 40px;
        font-size: 18px;
        transition: background-color 0.3s;
        }

        button:hover {
        background-color: #555;
        }

        /* Footer styling */
        footer {
        background-color: #333;
        color: #fff;
        text-align: center;
        padding: 10px;
        margin: 0 auto;
        }

        input::placeholder {
        color:white;
        }


        /* blog */
        .blog-text a{
            font-family: var(--Roboto);
            font-size: 1.1rem;
            text-decoration: none;
            color: var(--dark);
            display: inline-block;
            background: var(--dark);
            color: #fff;
            padding: 0.55rem 1.2rem;
            transition: all 0.5s ease;
        }

        /* about */
        .about{
            padding: 4.5rem 0;
        }
        .about-text{
            margin: 2rem 0;
        }
        .about-text > p{
            font-size: 1.1rem;
            padding: 0.6rem 0;
            opacity: 0.8;
        }

        /* footer */
        footer{
            background: var(--exDark);
            color: #fff;
            text-align: center;
            padding: 2rem 0;
        }
        .social-links{
            display: flex;
            justify-content: center;
            margin-bottom: 1.4rem;
        }
        .social-links a{
            border: 2px solid #fff;
            color: #fff;
            display: block;
            width: 40px;
            height: 40px;
            display: flex;
            justify-content: center;
            align-items: center;
            border-radius: 50%;
            text-decoration: none;
            margin: 0 0.3rem;
            transition: all 0.5s ease;
        }

        .social-links a:hover{
            background: #fff;
            color: var(--exDark);
        }
        .footer span{
            margin-top: 1rem;
            display: block;
            font-family: var(--Playfair);
            letter-spacing: 2px;
        }

        /* Media Queries */
        @media screen and (min-width: 540px){
            .navbar-nav a{
                padding-right: 1.2rem;
                padding-left: 1.2rem;
            }
            .banner form{
                margin-top: 1.4rem;
                width: 80%;
                margin-left: auto;
                margin-right: auto;
            }
        }

        @media screen and (min-width: 768px){
            .navbar .container{
                display: flex;
                align-items: center;
                justify-content: space-between;
            }
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 2rem;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 12px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }
    </style>

</head>
<body>

<header>
    <nav class="navbar">
        <div class="container">
            <a href="student_homepage.php" class="navbar-brand">HOME</a>
            <div class = "navbar-nav">
                <a href = "officer_upload.php">Upload File</a>
                <a href = "officer_manage2.php">Manage Students</a>
                <a href = "officer_manage1.php">Manage Companies</a>
                <a href = "index.php">Log Out</a>
            </div>
        </div>
    </nav>
</header>

<section class="about" id="about">
    <div class="container">
        <div class="title">
            <h2>Student Information</h2>
            <p>Industrial Training Management System</p><br>
        </div>

        <div class="center">
            <?php
            if (mysqli_num_rows($result) > 0) {
                echo "<table>";
                echo "<tr><th>Num.</th>
                      <th>Student Name</th>
                      <th>IC Number</th>
                      <th>Email</th>
                      <th>Parent Phone Number</th>
                      <th>Home Address</th>
                      <th>Bahasa Melayu Grade</th>
                      <th>English Grade</th>
                      <th>MUET Band</th>
                      <th>Mentor Name</th></tr>";
                
                // Output data of each row
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>
                            <td>" . $row["studentID"] . "</td>
                            <td>" . $row["studentName"] . "</td>
                            <td>" . $row["ICNumber"] . "</td>
                            <td>" . $row["email"] . "</td>
                            <td>" . $row["parentPhoneNumber"] . "</td>
                            <td>" . $row["homeAddress"] . "</td>
                            <td>" . $row["bmGrade"] . "</td>
                            <td>" . $row["engGrade"] . "</td>
                            <td>" . $row["muetBand"] . "</td>
                            <td>" . $row["mentorName"] . "</td>
                          </tr>";
                }
                echo "</table>";
            } else {
                echo "0 results";
            }

            // Close connection
            mysqli_close($conn);
            ?>
        </div>

        <!-- Navigation links -->
        <div class="center">
            <div class="blog-text">
                <a href="officer_manage.php">Manage Data</a>
            </div><br>

            <div class="blog-text">
                <a href="officer_homepage.php">Back</a>
            </div>
        </div>
    </div>
</section>

<footer>
    <div class="social-links">
        <a href="https://www.facebook.com/KPMBERANANGSELANGOR/?locale=ms_MY"><i class="fab fa-facebook-f"></i></a>
        <a href="https://x.com/MPPKPMBeranang"><i class="fab fa-twitter"></i></a>
        <a href="https://www.instagram.com/mppkpmb/?hl=en"><i class="fab fa-instagram"></i></a>
        <a href="https://www.tiktok.com/@kpm.beranang.sela?is_from_webapp=1&sender_device=pc"><i class="fab fa-tiktok"></i></a>
    </div>
    <span>&copy; 2024 i-Training. All rights reserved.</span>
</footer>

</body>
</html>
