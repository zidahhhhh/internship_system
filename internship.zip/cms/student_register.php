<?php
include 'config.php';

if(isset($_POST['submit'])){
   $full_name = $_POST['full_name'];
   $full_name = filter_var($full_name, FILTER_SANITIZE_STRING);
   $course = $_POST['course'];
   $course = filter_var($course, FILTER_SANITIZE_STRING);
   $semester = $_POST['semester'];
   $semester = filter_var($semester, FILTER_SANITIZE_STRING);
   $mentor_name = $_POST['mentor_name'];
   $mentor_name = filter_var($mentor_name, FILTER_SANITIZE_STRING);
   $email = $_POST['email'];
   $email = filter_var($email, FILTER_SANITIZE_EMAIL);
   $phone_number = $_POST['phone_number'];
   $phone_number = filter_var($phone_number, FILTER_SANITIZE_STRING);
   $username = $_POST['username'];
   $username = filter_var($username, FILTER_SANITIZE_STRING);
   $password = $_POST['password'];
   $password_hash = password_hash($password, PASSWORD_DEFAULT);

   // Check if the database connection is successful
   if ($conn->connect_error) {
       die("Connection failed: " . $conn->connect_error);
   }

   // Prepare the SQL query
   $insert = $conn->prepare("INSERT INTO `cms`.`users` (full_name, course, semester, mentor_name, email_address, phone_number, username, password) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");

   // Check if the prepare statement was successful
   if ($insert === false) {
       die('Prepare failed: ' . $conn->error);
   }

   $insert->bind_param("ssssssss", $full_name, $course, $semester, $mentor_name, $email, $phone_number, $username, $password_hash);

   if($insert->execute()){
      $message = 'Registration successful. Please login to continue.';
   }else{
      $message = 'Registration failed. Please try again.';
   }

   $insert->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Student Register</title>

   <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;700&display=swap" rel="stylesheet">

   <style>
      body {
         font-family: 'Poppins', sans-serif;
         margin: 0;
         padding: 0;
         background-color: #f0f0f0;
      }

      .form-container {
         max-width: 400px;
         margin: 50px auto;
         padding: 30px;
         background-color: #ffffff; /* Change to a lighter color, e.g., white */
         border-radius: 10px;
         box-shadow: 0 4px 6px rgba(0,0,0,0.1);
         text-align: center;
      }

      h3 {
         color: #4e2f5f;
         margin-bottom: 20px;
      }

      .box {
         padding: 10px;
         margin-bottom: 20px;
         width: 100%;
         border-radius: 5px;
         border: 1px solid #ccc;
         box-sizing: border-box;
      }

      .btn {
         padding: 10px 20px;
         background-color: #4e2f5f;
         color: #fff;
         border: none;
         border-radius: 5px;
         cursor: pointer;
         transition: background-color 0.3s;
      }

      .btn:hover {
         background-color: #693f7b;
      }

      .message {
         background-color: #f8d7da;
         color: #721c24;
         padding: 10px;
         margin-bottom: 20px;
         border-radius: 5px;
         border: 1px solid #f5c6cb;
         text-align: center;
         position: relative;
      }

      .message span {
         display: inline-block;
         vertical-align: middle;
         margin-right: 5px;
      }

      .message i {
         position: absolute;
         top: 50%;
         right: 10px;
         transform: translateY(-50%);
         cursor: pointer;
      }

   </style>

</head>
<body>

<?php if(isset($message)): ?>
   <div class="message">
      <span><?php echo $message; ?></span>
   </div>
<?php endif; ?>

<section class="form-container">

   <form action="" method="post" enctype="multipart/form-data">
      <h3>Student Register</h3>
      <input type="text" required placeholder="Enter your full name" class="box" name="full_name">
      <input type="text" required placeholder="Enter your course" class="box" name="course">
      <input type="text" required placeholder="Enter your semester" class="box" name="semester">
      <input type="text" required placeholder="Enter your mentor's name" class="box" name="mentor_name">
      <input type="email" required placeholder="Enter your email" class="box" name="email">
      <input type="text" required placeholder="Enter your phone number" class="box" name="phone_number">
      <input type="text" required placeholder="Enter your username" class="box" name="username">
      <input type="password" required placeholder="Enter your password" class="box" name="password">
      <p>Already have an account? <a href="student_login.php">Login Now</a></p>
      <input type="submit" value="Register Now" class="btn" name="submit">
   </form>

</section>

</body>
</html>
