<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>User Selection</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;700&display=swap" rel="stylesheet">
<style>
    body {
        font-family: 'Poppins', sans-serif;
        margin: 0;
        padding: 0;
        background-color: #f0f0f0;
    }
    .form-container {
        max-width: 400px;
        margin: 50px auto;
        padding: 30px;
        background-color: #f9f7f7;
        border-radius: 10px;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        text-align: center;
    }
    h1 {
        color: #4e2f5f;
        margin-bottom: 20px;
    }
    p {
        color: #6c757d;
        margin-bottom: 30px;
    }
    label {
        display: block;
        margin-bottom: 15px;
        color: #4e2f5f;
        font-weight: bold;
    }
    input[type="radio"] {
        margin-right: 10px;
    }
    button {
        padding: 10px 20px;
        background-color: #4e2f5f;
        color: #fff;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        transition: background-color 0.3s;
    }
    button:hover {
        background-color: #693f7b;
    }

    img {
        height: 150px;
        weight: 150px;
    }

</style>
</head>
<body>
   <div class="form-container">
       <img src="logoKPM.png" alt="College Logo" class="logo">
       <h1>Welcome</h1>
       <p>Please select your role:</p>
       <form method="POST" action="process_selection.php">
           <label><input type="radio" name="role" value="student"> Student</label>
           <label><input type="radio" name="role" value="officer">Officer</label>
           <button type="submit">Submit</button>
       </form>
   </div>

   <footer>
    <div class="social-links">
        <a href="https://www.facebook.com/KPMBERANANGSELANGOR/?locale=ms_MY"><i class="fab fa-facebook-f"></i></a>
        <a href="https://x.com/MPPKPMBeranang"><i class="fab fa-twitter"></i></a>
        <a href="https://www.instagram.com/mppkpmb/?hl=en"><i class="fab fa-instagram"></i></a>
        <a href="https://www.tiktok.com/@kpm.beranang.sela?is_from_webapp=1&sender_device=pc"><i class="fab fa-tiktok"></i></a>
    </div>
</footer>
</body>
</html>
