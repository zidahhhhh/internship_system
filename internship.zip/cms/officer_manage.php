<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "cms";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle CRUD operations
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add_user'])) {
        $name = $_POST['studentName'];
        $ic_number = $_POST['ICNumber'];
        $email = $_POST['email'];
        $phone = $_POST['parentPhoneNumber'];
        $address = $_POST['homeAddress'];
        $bm_grade = $_POST['bmGrade'];
        $eng_grade = $_POST['engGrade'];
        $muet_band = $_POST['muetBand'];
        $mentor_name = $_POST['mentorName'];
        $sql = "INSERT INTO student_info (studentName, ICNumber, email, parentPhoneNumber, homeAddress, bmGrade, engGrade, muetBand, mentorName) VALUES ('$name', '$ic_number', '$email', '$phone', '$address', '$bm_grade', '$eng_grade', '$muet_band', '$mentor_name')";
        $conn->query($sql);

    } elseif (isset($_POST['update_user'])) {
        $id = $_POST['studentID'];
        $name = $_POST['studentName'];
        $ic_number = $_POST['ICNumber'];
        $email = $_POST['email'];
        $phone = $_POST['parentPhoneNumber'];
        $address = $_POST['homeAddress'];
        $bm_grade = $_POST['bmGrade'];
        $eng_grade = $_POST['engGrade'];
        $muet_band = $_POST['muetBand'];
        $mentor_name = $_POST['mentorName'];
        $sql = "UPDATE student_info SET studentName='$name', ICNumber='$ic_number', email='$email', parentPhoneNumber='$phone', homeAddress='$address', bmGrade='$bm_grade', engGrade='$eng_grade', muetBand='$muet_band', mentorName='$mentor_name' WHERE studentID=$id";
        $conn->query($sql);

    } elseif (isset($_POST['delete_user'])) {
        $id = $_POST['studentID'];
        $sql = "DELETE FROM student_info WHERE studentID=$id";
        $conn->query($sql);

    } elseif (isset($_POST['add_company'])) {
        $name = $_POST['companyName'];
        $address = $_POST['companyAddress'];
        $state = $_POST['state'];
        $fax_number = $_POST['faxNumber'];
        $email = $_POST['email'];
        $person_in_charge = $_POST['personInCharge'];
        $position = $_POST['position'];
        $monthly_allowance = $_POST['monthlyAllowance'];
        $sql = "INSERT INTO company_info (companyName, companyAddress, state, faxNumber, email, personInCharge, position, monthlyAllowance) VALUES ('$name', '$address', '$state', '$fax_number', '$email', '$person_in_charge', '$position', '$monthly_allowance')";
        $conn->query($sql);

    } elseif (isset($_POST['update_company'])) {
        $id = $_POST['company_id'];
        $name = $_POST['companyName'];
        $address = $_POST['companyAddress'];
        $state = $_POST['state'];
        $fax_number = $_POST['faxNumber'];
        $email = $_POST['email'];
        $person_in_charge = $_POST['personInCharge'];
        $position = $_POST['position'];
        $monthly_allowance = $_POST['monthlyAllowance'];
        $sql = "UPDATE company_info SET companyName='$name', companyAddress='$address', state='$state', faxNumber='$fax_number', email='$email', personInCharge='$person_in_charge', position='$position', monthlyAllowance='$monthly_allowance' WHERE company_id=$id";
        $conn->query($sql);

    } elseif (isset($_POST['delete_company'])) {
        $id = $_POST['company_id'];
        $sql = "DELETE FROM company_info WHERE company_id=$id";
        $conn->query($sql);
    }
}

// Fetch users and company_info
$student_info = $conn->query("SELECT * FROM student_info");
$company_info = $conn->query("SELECT * FROM company_info");
?>

<!DOCTYPE html>
<html>
<head>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;600;700;800;900&family=Quicksand:wght@300;400;500;600;700&display=swap');

        :root{
            --Playfair: 'Playfair Display', serif;
            --Quicksand: 'Quicksand', sans-serif;
            --Roboto: 'Roboto', sans-serif;
            --dark: #3b393d87;
            --exDark: #2b2b2b;
        }
        *{
            padding: 0;
            margin: 0;
            font-family: var(--Quicksand);
        }
        body{
            line-height: 1.4;
            color: var(--dark);
        }
        img{
            width: 100%;
            display: block;
        }
        .container{
            max-width: 1320px;
            margin: 0 auto;
            padding: 0 1.2rem;
        }

        header{
            flex-direction: column;
            justify-content: stretch;
        }
        .navbar{
            background: rgba(0, 0, 0, 0.6);
            padding: 1.2rem;
        }
        .navbar-brand{
            color: #fff;
            font-size: 2rem;
            display: block;
            text-align: center;
            text-decoration: none;
            font-family: var(--Playfair);
            letter-spacing: 1px;
        }
        .navbar-nav{
            padding: 0.8rem 0 0.2rem 0;
            text-align: center;
        }
        .navbar-nav a{
            text-transform: uppercase;
            font-family: var(--Roboto);
            letter-spacing: 1px;
            font-weight: 500;
            color: #fff;
            text-decoration: none;
            display: inline-block;
            padding: 0.4rem 0.1rem;
            letter-spacing: 3px;
            transition: opacity 0.5s ease;
        }
        .navbar-nav a:hover{
            opacity: 0.7;
            color: rgb(221, 102, 102);
        }

        .design{
            padding: 4.5rem 0;
        }
        .title{
            text-align: center;
            padding: 1rem 0;
        }
        .title h2{
            font-family: var(--Playfair);
            font-size: 2.4rem;
            color: indianred;
        }
        .title p{
            text-transform: uppercase;
            padding: 0.6rem 0;
            color: darksalmon;
        }

        .input-box input{
            width: 100%;
            height: 100%;
            background: transparent;
            border: none;
            outline: none;
            border: 2px solid rgba(255, 255, 255, .2);
            border-radius: 40px;
            font-size: 16px;
            color: white;
            padding: 20px 45px 20px 20px;
        }

        .input-box i {
            position: absolute;
            right: 20px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 20px;
        }

        form {
            max-width: 400px;
            background: rgba(0, 0, 0, 0.5);
            color: white;
            border-radius: 10px;
            padding: 30px 40px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            margin: 0 auto;
        }

        form h1 {
            font-size: 26px;
            text-align: center;
            margin-top: 20px;
            color: lightblue;
        }

        .input-box {
            position: relative;
            width: 75%;
            height: 50px;
            margin: 20px 0;
        }

        .center {
            text-align: center;
        }

        .input-box input {
            width: 100%;
            height: 100%;
            background: transparent;
            border: none;
            outline: none;
            border: 2px solid rgba(255, 255, 255, 0.2);
            border-radius: 40px;
            font-size: 16px;
            color: white;
            padding: 20px 45px 20px 20px;
        }

        .input-box i {
            position: absolute;
            right: 20px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 20px;
        }

        button {
            width: 100%;
            padding: 10px;
            background-color: #4CAF50; /* Green background */
            color: #fff;
            text-decoration: none;
            border: none;
            cursor: pointer;
            border-radius: 40px;
            font-size: 18px;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #45a049;
        }

        footer {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 10px;
            margin: 0 auto;
        }

        input::placeholder {
            color: white;
        }

        .about {
            padding: 4.5rem 0;
        }
        .about-text {
            margin: 2rem 0;
        }
        .about-text > p {
            font-size: 1.1rem;
            padding: 0.6rem 0;
            opacity: 0.8;
        }

        footer {
            background: var(--exDark);
            color: #fff;
            text-align: center;
            padding: 2rem 0;
        }
        .social-links {
            display: flex;
            justify-content: center;
            margin-bottom: 1.4rem;
        }
        .social-links a {
            border: 2px solid #fff;
            color: #fff;
            display: block;
            width: 40px;
            height: 40px;
            display: flex;
            justify-content: center;
            align-items: center;
            border-radius: 50%;
            text-decoration: none;
            margin: 0 0.3rem;
            transition: all 0.5s ease;
        }

        .social-links a:hover {
            background: #fff;
            color: var(--exDark);
        }
        .footer span {
            margin-top: 1rem;
            display: block;
            font-family: var(--Playfair);
            letter-spacing: 1px;
        }
    </style>
</head>
<body>
    <header>
    <title>i-Training - CRUD</title>
        <nav class="navbar">
            <div class="container">
                <a href="officer_homepage.php" class="navbar-brand">Home</a>
                <div class = "navbar-nav">
                    <a href = "officer_upload.php">Upload File | </a>
                    <a href = "officer_manage2.php">Manage Students | </a>
                    <a href = "officer_manage1.php">Manage Companies | </a>
                    <a href = "index.php">Log Out</a>
                </div>
            </div>
        </nav>
    </header>

    <section class="design" id="users">
        <div class="container">
            <div class="title">
                <h2>Users</h2>
                <p>Manage Users</p>
            </div>
            <form method="POST" action="">
                <input type="hidden" name="studentID">
                <div class="input-box">
                    <input type="text" name="studentName" placeholder="Name" required>
                </div><br>
                <div class="input-box">
                    <input type="text" name="ICNumber" placeholder="IC Number" required>
                </div><br>
                <div class="input-box">
                    <input type="email" name="email" placeholder="Email" required>
                </div><br>
                <div class="input-box">
                    <input type="text" name="parentPhoneNumber" placeholder="Parent Phone Number" required>
                </div><br>
                <div class="input-box">
                    <input type="text" name="homeAddress" placeholder="Home Address" required>
                </div><br>
                <div class="input-box">
                    <input type="text" name="bmGrade" placeholder="BM Grade" required>
                </div><br>
                <div class="input-box">
                    <input type="text" name="engGrade" placeholder="English Grade" required>
                </div><br>
                <div class="input-box">
                    <input type="text" name="muetBand" placeholder="MUET Band" required>
                </div><br>
                <div class="input-box">
                    <input type="text" name="mentorName" placeholder="Mentor Name" required>
                </div><br><br>
                <button type="submit" name="add_user">Add User</button><br>
                <button type="submit" name="update_user">Update User</button><br>
                <button type="submit" name="delete_user">Delete User</button>
            </form>
        </div>
    </section>

    <section class="design" id="company_info">
        <div class="container">
            <div class="title">
                <h2>Companies</h2>
                <p>Manage Companies</p>
            </div>
            <form method="POST" action="">
                <input type="hidden" name="company_id">
                <div class="input-box">
                    <input type="text" name="companyName" placeholder="Name" required>
                </div><br>
                <div class="input-box">
                    <input type="text" name="companyAddress" placeholder="Address" required>
                </div><br>
                <div class="input-box">
                    <input type="text" name="state" placeholder="State" required>
                </div><br>
                <div class="input-box">
                    <input type="text" name="faxNumber" placeholder="Fax Number" required>
                </div><br>
                <div class="input-box">
                    <input type="email" name="email" placeholder="Email" required>
                </div><br>
                <div class="input-box">
                    <input type="text" name="personInCharge" placeholder="Person In Charge" required>
                </div><br>
                <div class="input-box">
                    <input type="text" name="position" placeholder="Position" required>
                </div><br>
                <div class="input-box">
                    <input type="text" name="monthlyAllowance" placeholder="Monthly Allowance" required>
                </div><br><br>
                <button type="submit" name="add_company">Add Company</button><br>
                <button type="submit" name="update_company">Update Company</button><br>
                <button type="submit" name="delete_company">Delete Company</button>
            </form><br><br>
            <center>
                <div class="blog-text">
                    <a href="officer_homepage.php">Back</a>
                </div>
            </center>
            
        </div>
    </section>
        
    <footer>
    <div class="social-links">
        <a href="https://www.facebook.com/KPMBERANANGSELANGOR/?locale=ms_MY"><i class="fab fa-facebook-f"></i></a>
        <a href="https://x.com/MPPKPMBeranang"><i class="fab fa-twitter"></i></a>
        <a href="https://www.instagram.com/mppkpmb/?hl=en"><i class="fab fa-instagram"></i></a>
        <a href="https://www.tiktok.com/@kpm.beranang.sela?is_from_webapp=1&sender_device=pc"><i class="fab fa-tiktok"></i></a>
    </div>
    <span>&copy; 2024 i-Training. All rights reserved.</span>
</footer>
</body>
</html>

<?php $conn->close(); ?>
