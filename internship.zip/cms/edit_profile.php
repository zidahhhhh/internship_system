<!DOCTYPE html>
<html>
<head>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;600;700;800;900&family=Quicksand:wght@300;400;500;600;700&display=swap');

        :root{
            --Playfair: 'Playfair Display', serif;
            --Quicksand: 'Quicksand', sans-serif;
            --Roboto: 'Roboto', sans-serif;
            --dark: #3b393d87;
            --exDark: #2b2b2b;
        }
        *{
            padding: 0;
            margin: 0;
            font-family: var(--Quicksand);
        }
        body{
            line-height: 1.4;
            color: var(--dark);
        }
        /* Update body styling */
        body{
            background-color: #f0f0f0; /* Example background color */
        }

        /* header */
        header{
            flex-direction: column;
            justify-content: stretch;
        }
        .navbar{
            background: rgba(0, 0, 0, 0.6);
            padding: 1.2rem;
        }
        .navbar-brand{
            color: #fff;
            font-size: 2rem;
            display: block;
            text-align: center;
            text-decoration: none;
            font-family: var(--Playfair);
            letter-spacing: 1px;
        }
        .navbar-nav{
            padding: 0.8rem 0 0.2rem 0;
            text-align: center;
        }
        .navbar-nav a{
            text-transform: uppercase;
            font-family: var(--Roboto);
            letter-spacing: 1px;
            font-weight: 500;
            color: #fff;
            text-decoration: none;
            display: inline-block;
            padding: 0.4rem 0.1rem;
            letter-spacing: 3px;
            transition: opacity 0.5s ease;
        }
        .navbar-nav a:hover{
            opacity: 0.7;
            color: rgb(221, 102, 102);
        }

        /* design */
        .design{
            padding: 4.5rem 0;
        }
        .title{
            text-align: center;
            padding: 1rem 0;
        }
        .title h2{
            font-family: var(--Playfair);
            font-size: 2.4rem;
            color:indianred;
        }
        .title p{
            text-transform: uppercase;
            padding: 0.6rem 0;
            color:darksalmon;
        }

        .input-box input{
              width: 100%;
              height: 100%;
              background: transparent;
              border: none;
              outline: none;
              border: 2px solid rgba(255, 255, 255, .2);
              border-radius: 40px;
              font-size: 16px;
              color: white;
              padding: 20px 45px 20px 20px;
          }

          .input-box i {
              position: absolute;
              right: 20px;
              top: 50%;
              transform: translateY(-50%);
              font-size: 20px;
          }

          form {
          max-width: 400px;
          background: rgba(0, 0, 0, 0.5);
          color: white;
          border-radius: 10px;
          padding: 30px 40px;
          display: flex;
          flex-direction: column;
          justify-content: center;
          align-items: center;
          margin: 0 auto;
        }

        form h1 {
          font-size: 26px;
          text-align: center;
          margin-top: 20px;
          color: lightblue;
        }

        /* Style the input boxes */
        .input-box {
          position: relative;
          width: 75%;
          height: 50px;
          margin: 20px 0;
        }

        .center {
          text-align: center;
        }

        .input-box input {
          width: 100%;
          height: 100%;
          background: transparent;
          border: none;
          outline: none;
          border: 2px solid rgba(255, 255, 255, 0.2);
          border-radius: 40px;
          font-size: 16px;
          color: white;
          padding: 20px 45px 20px 20px;
        }

        .input-box i {
          position: absolute;
          right: 20px;
          top: 50%;
          transform: translateY(-50%);
          font-size: 20px;
        }

        /* Style the "Submit" button */
        button {
          width: 100%;
          padding: 10px;
          background-color: #333;
          color: #fff;
          text-decoration: none;
          border: none;
          cursor: pointer;
          border-radius: 40px;
          font-size: 18px;
          transition: background-color 0.3s;
        }

        button:hover {
          background-color: #555;
        }

        /* Footer styling */
        footer {
          background-color: #333;
          color: #fff;
          text-align: center;
          padding: 10px;
          margin: 0 auto;
        }

        input::placeholder {
          color:white;
        }


        /* blog */
        .blog-text a{
            font-family: var(--Roboto);
            font-size: 1.1rem;
            text-decoration: none;
            color: var(--dark);
            display: inline-block;
            background: var(--dark);
            color: #fff;
            padding: 0.55rem 1.2rem;
            transition: all 0.5s ease;
        }

        /* about */
        .about{
            padding: 4.5rem 0;
        }
        .about-text{
            margin: 2rem 0;
        }
        .about-text > p{
            font-size: 1.1rem;
            padding: 0.6rem 0;
            opacity: 0.8;
        }

        /* footer */
        footer{
            background: var(--exDark);
            color: #fff;
            text-align: center;
            padding: 2rem 0;
        }
        .social-links{
            display: flex;
            justify-content: center;
            margin-bottom: 1.4rem;
        }
        .social-links a{
            border: 2px solid #fff;
            color: #fff;
            display: block;
            width: 40px;
            height: 40px;
            display: flex;
            justify-content: center;
            align-items: center;
            border-radius: 50%;
            text-decoration: none;
            margin: 0 0.3rem;
            transition: all 0.5s ease;
        }

        .social-links a:hover{
            background: #fff;
            color: var(--exDark);
        }
        .footer span{
            margin-top: 1rem;
            display: block;
            font-family: var(--Playfair);
            letter-spacing: 2px;
        }

        /* Media Queries */
        @media screen and (min-width: 540px){
            .navbar-nav a{
                padding-right: 1.2rem;
                padding-left: 1.2rem;
            }
            .banner form{
                margin-top: 1.4rem;
                width: 80%;
                margin-left: auto;
                margin-right: auto;
            }
        }

        @media screen and (min-width: 768px){
            .navbar .container{
                display: flex;
                align-items: center;
                justify-content: space-between;
            }
        }
    </style>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>i-Training - Edit Profile</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Font awesome icon -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" integrity="sha512-+4zCK9k+qNFUR5X+cKL9EIR+ZOhtIloNl9GIKS57V1MyNsYpYcUrUeQc9vNfzsWfV28IaLL3i96P9sdNyeRssA==" crossorigin="anonymous" />
    <link rel="stylesheet" href="style.css"> <!-- Include your main CSS file -->
</head>
<body>
    <!-- header -->
    <header>
        <nav class="navbar">
            <div class="container">
                <a href="student_homepage.php" class="navbar-brand">HOME</a>
                <div class="navbar-nav">
                    <a href="company_info.php">Company Information</a>
                    <a href="help.php">Help</a>
                    <a href="student_profile.php">Profile</a>
                </div>
            </div>
        </nav>
    </header>
    <!-- about -->
    <section class="about" id="about">
        <div class="container">
            <div>
                <div class="title">
                    <h2>Edit Profile</h2>
                    <form method="post">
                        <div class="input-box">
                            <input type="text" name="studentID" placeholder="Student ID" required>
                            <i class='bx bxs-lock-alt'></i>
                        </div><br>

                        <div class="input-box">
                            <input type="text" name="studentName" placeholder="Student Name" required>
                            <i class='bx bxs-lock-alt'></i>
                        </div><br>

                        <div class="input-box">
                            <input type="text" name="ICNumber" placeholder="IC Number" required>
                            <i class='bx bxs-lock-alt'></i>
                        </div><br>

                        <div class="input-box">
                            <input type="text" name="email" placeholder="Email" required>
                            <i class='bx bxs-lock-alt'></i>
                        </div><br>

                        <div class="input-box">
                            <input type="text" name="parentPhoneNumber" placeholder="Parent Phone Number" required>
                            <i class='bx bxs-lock-alt'></i>
                        </div><br>

                        <div class="input-box">
                            <input type="text" name="homeAddress" placeholder="Home Address" required>
                            <i class='bx bxs-lock-alt'></i>
                        </div><br>

                        <div class="input-box">
                            <input type="text" name="bmGrade" placeholder="Bahasa Melayu SPM Grade" required>
                            <i class='bx bxs-lock-alt'></i>
                        </div><br>

                        <div class="input-box">
                            <input type="text" name="engGrade" placeholder="English SPM Grade" required>
                            <i class='bx bxs-lock-alt'></i>
                        </div><br>
                        
                        <div class="input-box">
                            <input type="text" name="muetBand" placeholder="MUET Band" required>
                            <i class='bx bxs-lock-alt'></i>
                        </div><br>
                        
                        <div class="input-box">
                            <input type="text" name="mentorName" placeholder="Mentor Name" required>
                            <i class='bx bxs-lock-alt'></i>
                        </div><br><br>
                            <button type="submit">Save Changes</button>
                    </form>
                    <div class="blog-text"><br>
                        <a href="student_profile.php">Back to Profile</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- end of about -->
    <!-- footer -->
    <footer>
        <div class="social-links">
            <a href="#"><i class="fab fa-facebook-f"></i></a>
            <a href="#"><i class="fab fa-twitter"></i></a>
            <a href="#"><i class="fab fa-instagram"></i></a>
        </div>
        <span>&copy; 2024 Kolej Profesional Mara Beranang</span>
    </footer>
    <!-- end of footer -->
</body>
</html>
