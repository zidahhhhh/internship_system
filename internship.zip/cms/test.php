<?php
// Start the session (if not already started)
session_start();

// Check if studentID is set in session
if (!isset($_SESSION['studentID'])) {
    die("Session studentID not set.");
}

// Database credentials
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "cms_database";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Prepare SQL query
$studentID = $_SESSION['studentID'];
$sql = "SELECT * FROM student_profile WHERE studentID = ? LIMIT 1";
$stmt = $conn->prepare($sql);

if ($stmt === false) {
    die('Error preparing statement: ' . $conn->error);
}

// Bind parameters
$stmt->bind_param("s", $studentID);

// Execute query
$stmt->execute();

// Get result
$result = $stmt->get_result();

// Check if there is a result
if ($result->num_rows > 0) {
    // Fetch data as an associative array
    $row = $result->fetch_assoc();

    // Display or process fetched data
    echo "Student ID: " . $row['studentID'] . "<br>";
    echo "Name: " . $row['name'] . "<br>";
    echo "Email: " . $row['email'] . "<br>";
    // Add more fields as needed
} else {
    echo "No records found";
}

// Close statement and connection
$stmt->close();
$conn->close();
?>
