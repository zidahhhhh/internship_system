<!DOCTYPE html>
<html>
<head>
  <style>
     @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500&family=Quicksand&display=swap');

    :root {
    --Playfair: 'Playfair Display', serif;
    --Quicksand: 'Quicksand', sans-serif;
    --Roboto: 'Roboto', sans-serif;
    --dark: #3b393d87;
    --exDark: #2b2b2b;
    }

    * {
    padding: 0;
    margin: 0;
    font-family: var(--Quicksand);
    }

    body {
    line-height: 1.4;
    color: var(--dark);
    }

    img {
    width: 100%;
    display: block;
    }

    .container {
    max-width: 1320px;
    margin: 0 auto;
    padding: 0 1.2rem;
    }

    /* header */
    header {
    min-height: 100vh;
    background: linear-gradient(rgba(0, 0, 0, 0.4), rgba(0, 0, 0, 0.4)), url("{% static 'banner-bg.jpg' %}") center/cover no-repeat fixed;
    display: flex;
    flex-direction: column;
    justify-content: stretch;
    }

    .navbar {
    background: rgba(0, 0, 0, 0.6);
    padding: 1.2rem;
    }

    .navbar-brand {
    color: #fff;
    font-size: 2rem;
    display: block;
    text-align: center;
    text-decoration: none;
    font-family: var(--Playfair);
    letter-spacing: 1px;
    }

    .navbar-nav {
    padding: 0.8rem 0 0.2rem 0;
    text-align: center;
    }

    .navbar-nav a {
    text-transform: uppercase;
    font-family: var(--Roboto);
    letter-spacing: 1px;
    font-weight: 500;
    color: #fff;
    text-decoration: none;
    display: inline-block;
    padding: 0.4rem 0.1rem;
    letter-spacing: 3px;
    transition: opacity 0.5s ease;
    }

    .navbar-nav a:hover {
    opacity: 0.7;
    color: burlywood;
    }

    .banner {
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: center;
    text-align: center;
    color: #fff;
    }

    .banner-title {
    font-size: 3rem;
    font-family: var(--Playfair);
    line-height: 1.2;
    }

    .banner-title span {
    font-family: var(--Playfair);
    color: var(--exDark);
    }

    .banner p {
    padding: 1rem 0 2rem 0;
    font-size: 1.2rem;
    text-transform: capitalize;
    font-family: var(--Roboto);
    font-weight: 300;
    word-spacing: 2px;
    }

    .banner form {
    background: #fff;
    border-radius: 2rem;
    padding: 0.6rem 1rem;
    display: flex;
    justify-content: space-between;
    }

    .search-input {
    font-family: var(--Roboto);
    font-size: 1.1rem;
    width: 100%;
    outline: 0;
    padding: 0.6rem 0;
    border: none;
    }

    .search-input::placeholder {
    text-transform: capitalize;
    }

    .search-btn {
    width: 40px;
    font-size: 1.1rem;
    color: var(--dark);
    border: none;
    background: transparent;
    outline: 0;
    cursor: pointer;
    }

    /* design */
    .design {
    padding: 4.5rem 0;
    }

    .title {
    text-align: center;
    padding: 1rem 0;
    }

    .title h2 {
    font-family: var(--Playfair);
    font-size: 2.4rem;
    }

    .title p {
    text-transform: uppercase;
    padding: 0.6rem 0;
    }

    .design-content {
    margin: 2rem 0;
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 1rem;
    }

    .design-item {
    cursor: pointer;
    margin: 1.5rem 0;
    }

    .design-img {
    position: relative;
    overflow: hidden;
    }

    .design-img::after {
    position: absolute;
    content: "";
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.3);
    }

    .design-img img {
    transition: all 0.5s ease;
    }

    .design-item:hover img {
    transform: scale(1.2);
    }

    .design-img span:first-of-type {
    position: absolute;
    z-index: 1;
    top: 10px;
    left: 10px;
    background: var(--exDark);
    color: #fff;
    padding: 0.25rem 1rem;
    }

    .design-img span:last-of-type {
    position: absolute;
    z-index: 1;
    bottom: 10px;
    right: 10px;
    color: #fff;
    font-weight: 700;
    font-size: 1.1rem;
    }

    .design-title {
    padding: 1rem;
    font-size: 1.2rem;
    text-align: center;
    width: 70%;
    margin: 0 auto;
    }

    .design-title a {
    color: var(--dark);
    text-decoration: none;
    text-transform: capitalize;
    font-family: var(--Playfair);
    }

    /* blog */
    .blog {
    background: #f9f9f9;
    padding: 4.5rem 0;
    }

    .blog-content {
    margin: 2rem 0;
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 1rem;
    }

    .blog-item {
    margin-bottom: 2rem;
    padding: 1rem;
    background: #fff;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    .blog-img {
    position: relative;
    overflow: hidden;
    height: 200px;
    }

    .blog-img img {
    width: 100%;
    height: auto;
    transition: transform 0.3s ease;
    }

    .blog-text {
    padding: 1rem 0;
    }

    .blog-text span {
    font-weight: 300;
    display: block;
    padding-bottom: 0.5rem;
    }

    .blog-text h2 {
    font-family: var(--Playfair);
    padding: 1rem 0;
    font-size: 1.65rem;
    font-weight: 500;
    }

    .blog-text p {
    font-weight: 300;
    font-size: 1.1rem;
    opacity: 0.9;
    padding-bottom: 1.2rem;
    }

    .blog-text a {
    font-family: var(--Roboto);
    font-size: 1.1rem;
    text-decoration: none;
    color: var(--dark);
    display: inline-block;
    background: var(--dark);
    color: #fff;
    padding: 0.55rem 1.2rem;
    transition: all 0.5s ease;
    }

    .blog-text a:hover {
    background: var(--exDark);
    }

    /* footer */
    footer {
    background: var(--exDark);
    color: #fff;
    text-align: center;
    padding: 2rem 0;
    }

    .social-links {
    display: flex;
    justify-content: center;
    margin-bottom: 1.4rem;
    }

    .social-links a {
    border: 2px solid #fff;
    color: #fff;
    display: block;
    width: 40px;
    height: 40px;
    display: flex;
    justify-content: center;
    align-items: center;
    border-radius: 50%;
    text-decoration: none;
    margin: 0 0.3rem;
    transition: all 0.5s ease;
    }

    .social-links a:hover {
    background: #fff;
    color: var(--exDark);
    }

    .footer span {
    margin-top: 1rem;
    display: block;
    font-family: var(--Playfair);
    letter-spacing: 2px;
    }

    /* Media Queries */
    @media screen and (min-width: 540px) {
    .navbar-nav a {
        padding-right: 1.2rem;
        padding-left: 1.2rem;
    }
    }

    @media screen and (max-width: 768px) {
    .navbar-nav {
        display: flex;
        flex-direction: column;
        text-align: center;
        padding: 0 0.6rem;
        margin-bottom: 0.6rem;
    }

    .navbar-nav a {
        padding: 0.8rem 0.6rem;
        text-align: center;
        text-transform: capitalize;
        margin: 0.6rem 0.6rem;
        font-size: 2.8rem;
        color: #fff;
    }

    .banner-title {
        font-size: 5rem;
    }

    .banner p {
        padding: 2rem 2rem;
    }

    .design-content {
        text-align: center;
    }

    .design-item {
        margin-bottom: 5rem;
    }

    .design-img img {
        height: 35rem;
    }

    .design-title {
        width: 70%;
    }

    .blog-item {
        margin-bottom: 3rem;
        padding: 1rem;
    }

    .blog-title h2 {
        font-size: 1.2rem;
        padding: 2rem 0;
    }

    .blog-title p {
        font-size: 1.1rem;
        text-align: center;
    }

    .footer-links {
        font-size: 0.8rem;
        text-align: center;
    }

    .footer a {
        text-decoration: none;
    }

    .footer span {
        margin-top: 1rem;
        display: block;
        font-family: var(--Playfair);
        letter-spacing: 0.2rem;
    }
    }
  </style>
  <title>i-Training - Uploaded Files</title>
</head>
<!DOCTYPE html>
<html>
<head>
  <style>
    .container{
          max-width: 1320px;
          margin: 0 auto;
          padding: 0 1.2rem;
      }

     /* header */
     header{
            flex-direction: column;
            justify-content: stretch;
        }
        .navbar{
            background: rgba(0, 0, 0, 0.6);
            padding: 1.2rem;
        }
        .navbar-brand{
            color: #fff;
            font-size: 2rem;
            display: block;
            text-align: center;
            text-decoration: none;
            font-family: var(--Playfair);
            letter-spacing: 1px;
        }
        .navbar-nav{
            padding: 0.8rem 0 0.2rem 0;
            text-align: center;
        }
        .navbar-nav a{
            text-transform: uppercase;
            font-family: var(--Roboto);
            letter-spacing: 1px;
            font-weight: 500;
            color: #fff;
            text-decoration: none;
            display: inline-block;
            padding: 0.4rem 0.1rem;
            letter-spacing: 3px;
            transition: opacity 0.5s ease;
        }
        .navbar-nav a:hover{
            opacity: 0.7;
            color: rgb(221, 102, 102);
        }
      .banner{
          flex: 1;
          display: flex;
          align-items: center;
          justify-content: center;
          text-align: center;
          color: #fff;
      }
      .banner-title{
          font-size: 3rem;
          font-family: var(--Playfair);
          line-height: 1.2;
      }
      .banner-title span{
          font-family: var(--Playfair);
          color: var(--exDark);
      }
      .banner p{
          padding: 1rem 0 2rem 0;
          font-size: 1.2rem;
          text-transform: capitalize;
          font-family: var(--Roboto);
          font-weight: 300;
          word-spacing: 2px;
      }
      .banner form{
          background: #fff;
          border-radius: 2rem;
          padding: 0.6rem 1rem;
          display: flex;
          justify-content: space-between;
      }
        .file-data {
        margin-top: 2rem;
        padding: 1rem;
        background: #f9f9f9;
        border: 1px solid #ddd;
        border-radius: 5px;
        }
        .file-data h2 {
        font-family: var(--Playfair);
        font-size: 1.8rem;
        margin-bottom: 1rem;
        }
        .file-info {
        font-family: var(--Quicksand);
        font-size: 1.1rem;
        line-height: 1.6;
        }
  </style>

  <title>Uploaded File Details</title>
</head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" integrity="sha512-+4zCK9k+qNFUR5X+cKL9EIR+ZOhtIloNl9GIKS57V1MyNsYpYcUrUeQc9vNfzsWfV28IaLL3i96P9sdNyeRssA==" crossorigin="anonymous" />
<link rel="stylesheet" href="style.css">
<body>
  <nav class="navbar">
    <div class="container">
      <a href="officer_homepage.php" class="navbar-brand">Home</a>
      <div class="navbar-nav">
        <a href="officer_upload.php">Upload File</a>
        <a href="officer_manage.php">Manage Students/Companies</a>
        <a href="index.php">Log Out</a>
      </div>
    </div>
  </nav>

  <header>
    <div class="container">
      <div class="banner">
        <div class="banner-title">
          <h1>Uploaded File Details</h1>
        </div>
      </div>
    </div>

  <div class="container">
    <div class="file-data">
      <h2>Uploaded File Information</h2>
      <?php
      if ($_FILES && $_FILES['file']['error'] == UPLOAD_ERR_OK) {
        $file_name = $_FILES['file']['name'];
        $file_size = $_FILES['file']['size'];
        $file_type = $_FILES['file']['type'];
        $file_tmp = $_FILES['file']['tmp_name'];

        echo "<div class='file-info'>";
        echo "<p><strong>File Name:</strong> $file_name</p>";
        echo "<p><strong>File Size:</strong> $file_size bytes</p>";
        echo "<p><strong>File Type:</strong> $file_type</p>";
        echo "</div>";
      } else {
        echo "<p>There was an error uploading the file.</p>";
      }
      ?>
    </div>
  </div><br><br><br>
  <center>
  <div class="blog-text">
        <a href="officer_homepage.php">OK</a>
    </div>
    </center>
  <header>
  <footer>
    <div class="container">
      <div class="social-links">
        <a href="https://www.facebook.com/KPMBERANANGSELANGOR/?locale=ms_MY"><i class="fab fa-facebook-f"></i></a>
        <a href="https://x.com/MPPKPMBeranang"><i class="fab fa-twitter"></i></a>
        <a href="https://www.instagram.com/mppkpmb/?hl=en"><i class="fab fa-instagram"></i></a>
        <a href="https://www.tiktok.com/@kpm.beranang.sela?is_from_webapp=1&sender_device=pc"><i class="fab fa-tiktok"></i></a>
      </div>
      <span>&copy; 2024 Kolej Profesional Mara Beranang. All rights reserved.</span>
    </div>
  </footer>
</body>
</html>
