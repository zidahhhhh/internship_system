<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $role = $_POST["role"];
    switch ($role) {
        case "student":
            // Redirect to student login or register page
            header("Location: student_login.php");
            break;
        case "officer":
            // Redirect to officer login or register page
            header("Location: officer_login.php");
            break;
        default:
            // Invalid role
            echo "Invalid role selected.";
    }
} else {
    // Redirect back to the selection page if accessed directly
    header("Location: index.php");
}
?>
