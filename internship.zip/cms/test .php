<!DOCTYPE html>
<html>
<head>
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500&family=Quicksand&family=Poppins:wght@400;600&display=swap');

    :root {
      --Playfair: 'Playfair Display', serif;
      --Quicksand: 'Quicksand', sans-serif;
      --Poppins: 'Poppins', sans-serif;
      --dark: #3b393d87;
      --exDark: #2b2b2b;
    }
    * {
      padding: 0;
      margin: 0;
      font-family: var(--Poppins);
    }
    body {
      font-family: var(--Poppins);
      margin: 0;
      padding: 0;
      background-color: #f0f0f0;
    }
    .container {
      max-width: 800px;
      margin: 50px auto;
      padding: 30px;
      background-color: #ffffff;
      border-radius: 10px;
      box-shadow: 0 4px 6px rgba(0,0,0,0.1);
      text-align: center;
    }
    h1 {
      color: #4e2f5f;
      margin-bottom: 20px;
    }
    .btn {
      padding: 10px 20px;
      background-color: #4e2f5f;
      color: #fff;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      transition: background-color 0.3s;
      text-decoration: none;
    }
    .btn:hover {
      background-color: #693f7b;
    }
  </style>
  
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Dashboard</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Font awesome icon -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" integrity="sha512-+4zCK9k+qNFUR5X+cKL9EIR+ZOhtIloNl9GIKS57V1MyNsYpYcUrUeQc9vNfzsWfV28IaLL3i96P9sdNyeRssA==" crossorigin="anonymous" />
</head>
<body>

  <!-- header -->
  <header>
    <nav class="navbar">
      <div class="container">
        <a href="dashboard.html" class="navbar-brand">Home</a>
        <div class="navbar-nav">
          <a href="companyinfo.html">Company Information</a>
          <a href="help.html">Help</a>
          <a href="studentprofile.html">Profile</a>
          <a href="login1.html">Log Out</a>
        </div>
      </div>
    </nav>
    <div class="banner">
      <div class="container">
        <h1 class="banner-title">
          <span>I -</span> Training
        </h1>
        <p>The first industrial training management system</p>
      </div>
    </div>
  </header>
  <!-- end of header -->
  
  <!-- design -->
  <section class="design" id="design">
    <div class="container">
      <div class="title">
        <h2>Industrial Training</h2>
        <p>Big Company Information</p>
      </div>

      <div class="design-content">

        <!-- item -->
        <div class="design-item">
          <div class="design-img">
            <img src="petronas1.png" alt="">
            <span><i class="far fa-heart"></i> 35</span>
            <span>Petronas</span>
          </div>
          <div class="design-title">
            <a href="https://www.petronas.com/internship-apply/#">Petronas Internship</a>
          </div>
        </div>
        <!-- end of item -->

        <!-- item -->
        <div class="design-item">
          <div class="design-img">
            <img src="dell.jpg" alt="">
            <span><i class="far fa-heart"></i> 26</span>
            <span>Dell Technologies</span>
          </div>
          <div class="design-title">
            <a href="https://jobs.dell.com/en/employment/malaysia-internships-jobs/375/24213/1733045/2">Dell Technologies Internship</a>
          </div>
        </div>
        <!-- end of item -->

        <!-- item -->
        <div class="design-item">
          <div class="design-img">
            <img src="intel.png" alt="">
            <span><i class="far fa-heart"></i> 22</span>
            <span>Intel</span>
          </div>
          <div class="design-title">
            <a href="https://jobs.intel.com/en/job/penang/intel-malaysia-s-internship-program-intake-2024/41147/58586182272">Intel Internship</a>
          </div>
        </div>
        <!-- end of item -->

        <!-- item -->
        <div class="design-item">
          <div class="design-img">
            <img src="life.jpg" alt="">
            <span><i class="far fa-heart"></i> 23</span>
            <span>LifeStyle Garden</span>
          </div>
          <div class="design-title">
            <a href="https://www.lifestylegardens.com.my/index.html">LifeStyle Garden Internship</a>
          </div>
        </div>
        <!-- end of item -->

        <!-- item -->
        <div class="design-item">
          <div class="design-img">
            <img src="eco1.png" alt="">
            <span><i class="far fa-heart"></i> 59</span>
            <span>EcoGarden</span>
          </div>
          <div class="design-title">
            <a href="http://www.ecogarden.my/">EcoGarden Internship</a>
          </div>
        </div>
        <!-- end of item -->

        <!-- item -->
        <div class="design-item">
          <div class="design-img">
            <img src="green.png" alt="">
            <span><i class="far fa-heart"></i> 44</span>
            <span>GreenScape Garden</span>
          </div>
          <div class="design-title">
            <a href="https://www.greenscapegardening.com/">GreenScape Garden Internship</a>
          </div>
        </div>
        <!-- end of item -->

      </div>
    </div>
  </section>
  <!-- end of design -->


  <!-- blog -->
  <section class="blog" id="blog">
    <div class="container">
      <div class="title">
        <h2>Document</h2>
        <p>Industrial Training Document</p>
      </div>
      <div class="blog-content">

        <!-- item -->
        <div class="blog-item">
          <div class="blog-img">
            <img src="pdf2.jpg" alt="">
            <span><i class="far fa-heart"></i></span>
          </div>
          <div class="blog-text">
            <span>10 May, 2022</span>
            <h2>Cover Letter</h2>
            <div class="design-title">
              <a href="coverletter.pdf" download="coverletter.pdf">Download</a>
            </div>
          </div>
        </div>
        <!-- end of item -->

        <!-- item -->
        <div class="blog-item">
          <div class="blog-img">
            <img src="pdf2.jpg" alt="">
            <span><i class="far fa-heart"></i></span>
          </div>
          <div class="blog-text">
            <span>10 May, 2022</span>
            <h2>Borang Senarai Semak UPP</h2>
            <div class="design-title">
              <a href="senaraisemak.pdf" download="senaraisemak.pdf">Download</a>
            </div>
          </div>
        </div>
        <!-- end of item -->

        <!-- item -->
        <div class="blog-item">
          <div class="blog-img">
            <img src="pdf2.jpg" alt="">
            <span><i class="far fa-heart"></i></span>
          </div>
          <div class="blog-text">
            <span>13 October, 2023</span>
            <h2>Manual Latihan Industri KPM Edisi 2 2023</h2>
            <div class="design-title">
              <a href="manual.pdf" download="manual.pdf">Download</a>
            </div>
          </div>
        </div>
        <!-- end of item -->

        <!-- item -->
        <div class="blog-item">
          <div class="blog-img">
            <img src="pdf2.jpg" alt="">
            <span><i class="far fa-heart"></i></span>
          </div>
          <div class="blog-text">
            <span>10 May, 2022</span>
            <h2>Cadangan Terma Rujukan Syar
