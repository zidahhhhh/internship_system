<!DOCTYPE html>
<html>
<head>
<style>
    @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500&family=Quicksand&display=swap');
    
    :root {
        --Playfair: 'Playfair Display', serif;
        --Quicksand: 'Quicksand', sans-serif;
        --Roboto: 'Roboto', sans-serif;
        --dark: #3b393d87;
        --exDark: #2b2b2b;
    }

    * {
        padding: 0;
        margin: 0;
        font-family: var(--Quicksand);
    }

    body {
        line-height: 1.4;
        color: var(--dark);
    }

    .container {
        max-width: 1320px;
        margin: 0 auto;
        padding: 0 1.2rem;
    }

    /* Navbar */
    .navbar {
        background: rgba(0, 0, 0, 0.6);
        padding: 1.2rem;
    }

    .navbar .container {
        display: flex;
        align-items: center;
        justify-content: space-between;
    }

    .navbar-brand {
        color: #fff;
        font-size: 2rem;
        display: block;
        text-align: center;
        text-decoration: none;
        font-family: var(--Playfair);
        letter-spacing: 1px;
    }

    .navbar-nav {
        padding: 0.8rem 0 0.2rem 0;
        text-align: center;
    }

    .navbar-nav a {
        text-transform: uppercase;
        font-family: var(--Roboto);
        letter-spacing: 1px;
        font-weight: 500;
        color: #fff;
        text-decoration: none;
        display: inline-block;
        padding: 0.4rem 0.1rem;
        letter-spacing: 3px;
        transition: opacity 0.5s ease;
    }

    .navbar-nav a:hover {
        opacity: 0.7;
        color: burlywood;
    }

    /* Header */
    header {
        min-height: 100vh;
        background: linear-gradient(rgba(0, 0, 0, 0.4), rgba(0, 0, 0, 0.4)), url("{% static 'banner-bg.jpg' %}") center/cover no-repeat fixed;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        text-align: center;
    }

    .banner-title {
        font-family: var(--Playfair);
        font-size: 1rem;
        color: #fff;
        margin-top: 1rem;
    }

    h1{
        font-family: var(--Playfair);
        font-size: 100px;
        color: #fff;
        margin-top: 1rem;
    }

    .banner p {
        padding: 1rem 0 2rem 0;
        font-size: 1.2rem;
        text-transform: capitalize;
        font-family: var(--Roboto);
        font-weight: 300;
        word-spacing: 2px;
    }

    .banner form {
        background: #fff;
        border-radius: 2rem;
        padding: 0.6rem 1rem;
        display: flex;
        justify-content: space-between;
        width: 80%;
        margin: 1.4rem auto;
    }
    

    .search-input {
        font-family: var(--Roboto);
        font-size: 1.1rem;
        width: 100%;
        outline: 0;
        padding: 0.6rem 0;
        border: none;
    }

    .search-input::placeholder {
        text-transform: capitalize;
    }

    .search-btn {
        width: 40px;
        font-size: 1.1rem;
        color: var(--dark);
        border: none;
        background: transparent;
        outline: 0;
        cursor: pointer;
    }

    /* footer */
    footer{
        background: var(--exDark);
        color: #fff;
        text-align: center;
        padding: 2rem 0;
    }
    .social-links{
        display: flex;
        justify-content: center;
        margin-bottom: 1.4rem;
    }
    .social-links a{
        border: 2px solid #fff;
        color: #fff;
        display: block;
        width: 40px;
        height: 40px;
        display: flex;
        justify-content: center;
        align-items: center;
        border-radius: 50%;
        text-decoration: none;
        margin: 0 0.3rem;
        transition: all 0.5s ease;
    }

    .social-links a:hover{
        background: #fff;
        color: var(--exDark);
    }
    .footer span{
        margin-top: 1rem;
        display: block;
        font-family: var(--Playfair);
        letter-spacing: 2px;
    }

    /* Media Queries */
    @media screen and (min-width: 540px) {
        .navbar-nav a {
            padding-right: 1.2rem;
            padding-left: 1.2rem;
        }
    }

    @media screen and (min-width: 768px) {
        .navbar-nav {
            display: flex;
            justify-content: center;
        }

        .banner-title {
            font-size: 5rem;
        }

        .banner form {
            margin-top: 1.4rem;
            width: 60%;
        }
    }

    @media screen and (min-width: 992px) {
        .banner form {
            width: 50%;
        }
    }
</style>

  <title>i-Training - Upload</title>
</head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" integrity="sha512-+4zCK9k+qNFUR5X+cKL9EIR+ZOhtIloNl9GIKS57V1MyNsYpYcUrUeQc9vNfzsWfV28IaLL3i96P9sdNyeRssA==" crossorigin="anonymous" />
<link rel="stylesheet" href="style.css">
<body>
    <nav class = "navbar">
        <div class = "container">
          <a href = "officer_homepage.php" class = "navbar-brand">Home</a>
          <div class = "navbar-nav">
                <a href = "officer_upload.php">Upload File</a>
                <a href = "officer_manage2.php">Manage Students</a>
                <a href = "officer_manage1.php">Manage Companies</a>
                <a href = "index.php">Log Out</a>
            </div>
        </div>
      </nav>

  <header>
    <div class="container">
      <div class="banner">
        <div class="banner-title">
          <h1>Upload Industrial Training Files</h1><br>
        </div>

        <form action="upload.php" method="POST" enctype="multipart/form-data">
          <input type="file" name="file" id="file">
          <button type="submit" name="submit">Upload</button>
        </form>
      </div>
    </div>
  </header>

  <footer>
    <div class="social-links">
        <a href="https://www.facebook.com/KPMBERANANGSELANGOR/?locale=ms_MY"><i class="fab fa-facebook-f"></i></a>
        <a href="https://x.com/MPPKPMBeranang"><i class="fab fa-twitter"></i></a>
        <a href="https://www.instagram.com/mppkpmb/?hl=en"><i class="fab fa-instagram"></i></a>
        <a href="https://www.tiktok.com/@kpm.beranang.sela?is_from_webapp=1&sender_device=pc"><i class="fab fa-tiktok"></i></a>
    </div>
    <span>&copy; 2024 i-Training. All rights reserved.</span>
</footer>
</body>
</html>

