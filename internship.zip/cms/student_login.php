<?php
include 'config.php';
session_start();

// Check if the user is already logged in
if(isset($_SESSION['student_id'])){
   header('location:student_profile.php');
   exit();
}

// Array to store error messages
$message = [];

// Check if the login form was submitted
if(isset($_POST['submit'])){
   $email = $_POST['email'];
   $email = filter_var($email, FILTER_SANITIZE_EMAIL); // Sanitize email input
   $pass = $_POST['pass'];
   $pass = filter_var($pass, FILTER_SANITIZE_STRING); // Sanitize password input

   // Prepare SQL statement to fetch user by email
   $select = $conn->prepare("SELECT * FROM `users` WHERE email_address = ?");
   
   if ($select === false) {
       die('Prepare failed: ' . $conn->error);
   }

   // Bind parameters and execute SQL query
   $select->bind_param("s", $email);
   $select->execute();
   $result = $select->get_result();

   // Check if user exists and verify password
   if($result->num_rows > 0){
      $users = $result->fetch_assoc();
      if(password_verify($pass, $users['password'])){
         // Set session variable and redirect to student homepage
         $_SESSION['student_id'] = $users['id'];
         header('location: student_homepage.php');
         exit();
      } else {
         // Password verification failed
         $msg = 'Login Failed!<br /> Please make sure that you enter the correct details .';
         $message[] = $msg;
      }
   } 
   else {
      // User not found
      $msg = 'Login Failed!<br /> Please make sure that you enter the correct details and that you have activated your account.';
      $message[] = $msg;
   }

   // Close prepared statement
   $select->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Student Login</title>

   <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;700&display=swap" rel="stylesheet">

   <style>
      body {
         font-family: 'Poppins', sans-serif;
         margin: 0;
         padding: 0;
         background-color: #f0f0f0;
      }

      .form-container {
         max-width: 400px;
         margin: 50px auto;
         padding: 30px;
         background-color: #ffffff;
         border-radius: 10px;
         box-shadow: 0 4px 6px rgba(0,0,0,0.1);
         text-align: center;
      }

      h3 {
         color: #4e2f5f;
         margin-bottom: 20px;
      }

      .box {
         padding: 10px;
         margin-bottom: 20px;
         width: 100%;
         border-radius: 5px;
         border: 1px solid #ccc;
         box-sizing: border-box;
      }

      .btn {
         padding: 10px 20px;
         background-color: #4e2f5f;
         color: #fff;
         border: none;
         border-radius: 5px;
         cursor: pointer;
         transition: background-color 0.3s;
      }

      .btn:hover {
         background-color: #693f7b;
      }

      .message {
         background-color: #f8d7da;
         color: #721c24;
         padding: 10px;
         margin-bottom: 20px;
         border-radius: 5px;
         border: 1px solid #f5c6cb;
         text-align: center;
         position: relative;
      }

      .message span {
         display: inline-block;
         vertical-align: middle;
         margin-right: 5px;
      }

      .message i {
         position: absolute;
         top: 50%;
         right: 10px;
         transform: translateY(-50%);
         cursor: pointer;
      }

   </style>

</head>
<body>

<?php if(!empty($message)): ?>
   <?php foreach($message as $msg): ?>
      <div class="message">
         <span><?php echo $msg; ?></span>
         <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
      </div>
   <?php endforeach; ?>
<?php endif; ?>

<section class="form-container">

   <form action="" method="post" enctype="multipart/form-data">
      <h3>Student Login</h3>
      <input type="email" required placeholder="Enter your email" class="box" name="email">
      <input type="password" required placeholder="Enter your password" class="box" name="pass">
      <p>Don't have an account? <a href="student_register.php">Register Now</a></p>
      <input type="submit" value="Login Now" class="btn" name="submit"  formaction="student_homepage.php">
   </form>

</section>

</body>
</html>
